# Sophie Patel

- **Position:** Senior Agent  
- **Date of Birth:** 1994-04-15  
- **Start Date:** 2017-01-27  
- **Email:** sophie.patel@horizonhaven.com  
- **Phone:** +1-881-540-8307  
- **Bio:** Sophie Patel has over 6 years of experience in real estate and plays a crucial role in our senior agent operations.