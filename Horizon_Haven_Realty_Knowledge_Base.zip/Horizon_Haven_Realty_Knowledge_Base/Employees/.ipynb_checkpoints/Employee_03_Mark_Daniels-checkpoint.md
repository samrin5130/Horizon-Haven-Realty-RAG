# Mark Daniels

- **Position:** CFO  
- **Date of Birth:** 1980-04-08  
- **Start Date:** 2019-02-01  
- **Email:** mark.daniels@horizonhaven.com  
- **Phone:** +1-221-956-7636  
- **Bio:** Mark Daniels has over 14 years of experience in real estate and plays a crucial role in our cfo operations.