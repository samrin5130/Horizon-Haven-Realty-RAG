# Bradley Kim

- **Position:** CEO  
- **Date of Birth:** 1979-07-26  
- **Start Date:** 2020-03-07  
- **Email:** bradley.kim@horizonhaven.com  
- **Phone:** +1-260-928-4856  
- **Bio:** Bradley Kim has over 12 years of experience in real estate and plays a crucial role in our ceo operations.