# Sophie Smith

- **Position:** CRM Specialist  
- **Date of Birth:** 1982-06-14  
- **Start Date:** 2015-02-07  
- **Email:** sophie.smith@horizonhaven.com  
- **Phone:** +1-829-796-4316  
- **Bio:** Sophie Smith has over 10 years of experience in real estate and plays a crucial role in our crm specialist operations.