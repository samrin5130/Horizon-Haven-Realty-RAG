# Oscar Bennett

- **Position:** Junior Agent  
- **Date of Birth:** 1977-11-27  
- **Start Date:** 2016-10-24  
- **Email:** oscar.bennett@horizonhaven.com  
- **Phone:** +1-124-849-4726  
- **Bio:** Oscar Bennett has over 10 years of experience in real estate and plays a crucial role in our junior agent operations.