# Laura Rivera

- **Position:** Sales Director  
- **Date of Birth:** 1977-11-14  
- **Start Date:** 2017-01-24  
- **Email:** laura.rivera@horizonhaven.com  
- **Phone:** +1-643-890-5891  
- **Bio:** Laura Rivera has over 8 years of experience in real estate and plays a crucial role in our sales director operations.