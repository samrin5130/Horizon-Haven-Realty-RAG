# Laura Chang

- **Position:** Customer Success Manager  
- **Date of Birth:** 1984-07-11  
- **Start Date:** 2023-06-22  
- **Email:** laura.chang@horizonhaven.com  
- **Phone:** +1-540-814-3363  
- **Bio:** Laura Chang has over 11 years of experience in real estate and plays a crucial role in our customer success manager operations.