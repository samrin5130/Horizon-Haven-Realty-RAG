# Jonathan Wong

- **Position:** HR Coordinator  
- **Date of Birth:** 1995-11-28  
- **Start Date:** 2018-02-20  
- **Email:** jonathan.wong@horizonhaven.com  
- **Phone:** +1-540-564-8015  
- **Bio:** Jonathan Wong has over 14 years of experience in real estate and plays a crucial role in our hr coordinator operations.