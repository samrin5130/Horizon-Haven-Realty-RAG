# Mark Bennett

- **Position:** Leasing Consultant  
- **Date of Birth:** 1988-10-16  
- **Start Date:** 2018-10-25  
- **Email:** mark.bennett@horizonhaven.com  
- **Phone:** +1-891-999-4537  
- **Bio:** Mark Bennett has over 10 years of experience in real estate and plays a crucial role in our leasing consultant operations.