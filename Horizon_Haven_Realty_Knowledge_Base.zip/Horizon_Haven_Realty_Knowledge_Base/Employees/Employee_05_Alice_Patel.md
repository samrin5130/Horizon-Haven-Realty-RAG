# Alice Patel

- **Position:** Property Manager  
- **Date of Birth:** 1987-09-07  
- **Start Date:** 2021-05-08  
- **Email:** alice.patel@horizonhaven.com  
- **Phone:** +1-576-619-8730  
- **Bio:** Alice Patel has over 5 years of experience in real estate and plays a crucial role in our property manager operations.