# Mark Tran

- **Position:** Accounts Executive  
- **Date of Birth:** 1983-09-27  
- **Start Date:** 2023-08-31  
- **Email:** mark.tran@horizonhaven.com  
- **Phone:** +1-609-696-8445  
- **Bio:** Mark Tran has over 10 years of experience in real estate and plays a crucial role in our accounts executive operations.