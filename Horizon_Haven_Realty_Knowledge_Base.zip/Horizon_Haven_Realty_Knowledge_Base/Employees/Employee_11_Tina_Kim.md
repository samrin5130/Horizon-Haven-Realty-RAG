# Tina Kim

- **Position:** IT Support  
- **Date of Birth:** 1978-08-19  
- **Start Date:** 2015-11-04  
- **Email:** tina.kim@horizonhaven.com  
- **Phone:** +1-375-732-1681  
- **Bio:** Tina Kim has over 3 years of experience in real estate and plays a crucial role in our it support operations.