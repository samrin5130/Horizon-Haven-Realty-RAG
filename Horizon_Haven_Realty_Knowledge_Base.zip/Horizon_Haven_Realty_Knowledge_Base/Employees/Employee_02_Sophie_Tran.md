# Sophie Tran

- **Position:** COO  
- **Date of Birth:** 1994-07-08  
- **Start Date:** 2015-04-02  
- **Email:** sophie.tran@horizonhaven.com  
- **Phone:** +1-675-336-1411  
- **Bio:** Sophie Tran has over 5 years of experience in real estate and plays a crucial role in our coo operations.