# Priya Chang

- **Position:** Legal Counsel  
- **Date of Birth:** 1978-12-01  
- **Start Date:** 2019-08-03  
- **Email:** priya.chang@horizonhaven.com  
- **Phone:** +1-571-773-8957  
- **Bio:** Priya Chang has over 14 years of experience in real estate and plays a crucial role in our legal counsel operations.