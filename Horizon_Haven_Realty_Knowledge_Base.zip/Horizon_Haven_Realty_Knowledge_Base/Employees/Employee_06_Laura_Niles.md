# Laura Niles

- **Position:** Marketing Lead  
- **Date of Birth:** 1979-01-04  
- **Start Date:** 2017-01-21  
- **Email:** laura.niles@horizonhaven.com  
- **Phone:** +1-405-966-1384  
- **Bio:** Laura Niles has over 11 years of experience in real estate and plays a crucial role in our marketing lead operations.