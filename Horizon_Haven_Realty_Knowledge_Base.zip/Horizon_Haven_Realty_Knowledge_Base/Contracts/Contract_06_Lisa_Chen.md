# Partnership Agreement - Lisa Chen

- **Contract Type:** Partnership Agreement  
- **Client Name:** Lisa Chen  
- **Effective Date:** 2024-09-07  
- **Expiration Date:** 2025-09-22  
- **Agent:** 13 Laura Chang  
- **Property Address:** 965 Elm Rd, San Francisco, USA  

## Terms and Conditions

This partnership agreement is entered into by and between **Lisa Chen** and Horizon Haven Realty. It outlines the terms of engagement for real estate services rendered by **13 Laura Chang**, including commissions, responsibilities, confidentiality, and legal obligations.

## Signatures

Client Signature: ____________________  
Horizon Haven Agent Signature: ____________________  
Date: 2024-09-07