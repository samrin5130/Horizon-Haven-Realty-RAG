# Partnership Agreement - Aisha Nguyen

- **Contract Type:** Partnership Agreement  
- **Client Name:** Aisha Nguyen  
- **Effective Date:** 2022-08-21  
- **Expiration Date:** 2025-06-24  
- **Agent:** 04 Laura Rivera  
- **Property Address:** 9729 Main St, San Francisco, USA  

## Terms and Conditions

This partnership agreement is entered into by and between **Aisha Nguyen** and Horizon Haven Realty. It outlines the terms of engagement for real estate services rendered by **04 Laura Rivera**, including commissions, responsibilities, confidentiality, and legal obligations.

## Signatures

Client Signature: ____________________  
Horizon Haven Agent Signature: ____________________  
Date: 2022-08-21