# Purchase Agreement - Daniel Lee

- **Contract Type:** Purchase Agreement  
- **Client Name:** Daniel Lee  
- **Effective Date:** 2022-06-03  
- **Expiration Date:** 2025-12-01  
- **Agent:** 14 Mark Tran  
- **Property Address:** 1457 Elm Rd, Miami, USA  

## Terms and Conditions

This purchase agreement is entered into by and between **Daniel Lee** and Horizon Haven Realty. It outlines the terms of engagement for real estate services rendered by **14 Mark Tran**, including commissions, responsibilities, confidentiality, and legal obligations.

## Signatures

Client Signature: ____________________  
Horizon Haven Agent Signature: ____________________  
Date: 2022-06-03