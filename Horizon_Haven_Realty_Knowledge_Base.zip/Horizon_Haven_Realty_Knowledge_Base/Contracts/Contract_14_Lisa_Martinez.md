# Buyer Agreement - Lisa Martinez

- **Contract Type:** Buyer Agreement  
- **Client Name:** Lisa Martinez  
- **Effective Date:** 2022-12-21  
- **Expiration Date:** 2025-05-04  
- **Agent:** 09 Oscar Bennett  
- **Property Address:** 6884 Main St, Chicago, USA  

## Terms and Conditions

This buyer agreement is entered into by and between **Lisa Martinez** and Horizon Haven Realty. It outlines the terms of engagement for real estate services rendered by **09 Oscar Bennett**, including commissions, responsibilities, confidentiality, and legal obligations.

## Signatures

Client Signature: ____________________  
Horizon Haven Agent Signature: ____________________  
Date: 2022-12-21