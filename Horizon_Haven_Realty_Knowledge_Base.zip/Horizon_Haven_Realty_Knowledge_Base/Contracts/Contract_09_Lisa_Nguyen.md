# Purchase Agreement - Lisa Nguyen

- **Contract Type:** Purchase Agreement  
- **Client Name:** Lisa Nguyen  
- **Effective Date:** 2024-06-15  
- **Expiration Date:** 2025-07-19  
- **Agent:** 06 Laura Niles  
- **Property Address:** 8121 Sunset Blvd, Chicago, USA  

## Terms and Conditions

This purchase agreement is entered into by and between **Lisa Nguyen** and Horizon Haven Realty. It outlines the terms of engagement for real estate services rendered by **06 Laura Niles**, including commissions, responsibilities, confidentiality, and legal obligations.

## Signatures

Client Signature: ____________________  
Horizon Haven Agent Signature: ____________________  
Date: 2024-06-15