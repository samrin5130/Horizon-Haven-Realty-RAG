# Lease Agreement - Aisha Lee

- **Contract Type:** Lease Agreement  
- **Client Name:** Aisha Lee  
- **Effective Date:** 2022-09-03  
- **Expiration Date:** 2025-04-24  
- **Agent:** 04 Laura Rivera  
- **Property Address:** 1667 Elm Rd, Chicago, USA  

## Terms and Conditions

This lease agreement is entered into by and between **Aisha Lee** and Horizon Haven Realty. It outlines the terms of engagement for real estate services rendered by **04 Laura Rivera**, including commissions, responsibilities, confidentiality, and legal obligations.

## Signatures

Client Signature: ____________________  
Horizon Haven Agent Signature: ____________________  
Date: 2022-09-03