# Listing Agreement - John Martinez

- **Contract Type:** Listing Agreement  
- **Client Name:** John Martinez  
- **Effective Date:** 2024-11-25  
- **Expiration Date:** 2025-11-22  
- **Agent:** 03 Mark Daniels  
- **Property Address:** 1029 Sunset Blvd, San Francisco, USA  

## Terms and Conditions

This listing agreement is entered into by and between **John Martinez** and Horizon Haven Realty. It outlines the terms of engagement for real estate services rendered by **03 Mark Daniels**, including commissions, responsibilities, confidentiality, and legal obligations.

## Signatures

Client Signature: ____________________  
Horizon Haven Agent Signature: ____________________  
Date: 2024-11-25