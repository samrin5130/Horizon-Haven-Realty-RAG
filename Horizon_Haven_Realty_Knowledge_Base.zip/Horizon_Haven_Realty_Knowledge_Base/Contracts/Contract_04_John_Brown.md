# Purchase Agreement - John Brown

- **Contract Type:** Purchase Agreement  
- **Client Name:** John Brown  
- **Effective Date:** 2024-08-17  
- **Expiration Date:** 2026-06-19  
- **Agent:** 07 Priya Chang  
- **Property Address:** 7699 Sunset Blvd, Miami, USA  

## Terms and Conditions

This purchase agreement is entered into by and between **John Brown** and Horizon Haven Realty. It outlines the terms of engagement for real estate services rendered by **07 Priya Chang**, including commissions, responsibilities, confidentiality, and legal obligations.

## Signatures

Client Signature: ____________________  
Horizon Haven Agent Signature: ____________________  
Date: 2024-08-17