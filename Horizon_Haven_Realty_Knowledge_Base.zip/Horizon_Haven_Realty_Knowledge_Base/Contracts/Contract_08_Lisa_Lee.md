# Buyer Agreement - Lisa Lee

- **Contract Type:** Buyer Agreement  
- **Client Name:** Lisa Lee  
- **Effective Date:** 2024-04-20  
- **Expiration Date:** 2026-08-30  
- **Agent:** 10 Mark Bennett  
- **Property Address:** 4060 Maple Drive, San Francisco, USA  

## Terms and Conditions

This buyer agreement is entered into by and between **Lisa Lee** and Horizon Haven Realty. It outlines the terms of engagement for real estate services rendered by **10 Mark Bennett**, including commissions, responsibilities, confidentiality, and legal obligations.

## Signatures

Client Signature: ____________________  
Horizon Haven Agent Signature: ____________________  
Date: 2024-04-20