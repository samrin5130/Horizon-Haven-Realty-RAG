# Lease Agreement - Daniel Brown

- **Contract Type:** Lease Agreement  
- **Client Name:** Daniel Brown  
- **Effective Date:** 2022-12-30  
- **Expiration Date:** 2025-10-25  
- **Agent:** 03 Mark Daniels  
- **Property Address:** 6311 Elm Rd, Austin, USA  

## Terms and Conditions

This lease agreement is entered into by and between **Daniel Brown** and Horizon Haven Realty. It outlines the terms of engagement for real estate services rendered by **03 Mark Daniels**, including commissions, responsibilities, confidentiality, and legal obligations.

## Signatures

Client Signature: ____________________  
Horizon Haven Agent Signature: ____________________  
Date: 2022-12-30