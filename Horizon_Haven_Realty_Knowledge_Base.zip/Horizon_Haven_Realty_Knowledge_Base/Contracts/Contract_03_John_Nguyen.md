# Lease Agreement - John Nguyen

- **Contract Type:** Lease Agreement  
- **Client Name:** John Nguyen  
- **Effective Date:** 2023-03-10  
- **Expiration Date:** 2025-10-04  
- **Agent:** 04 Laura Rivera  
- **Property Address:** 4081 Elm Rd, Miami, USA  

## Terms and Conditions

This lease agreement is entered into by and between **John Nguyen** and Horizon Haven Realty. It outlines the terms of engagement for real estate services rendered by **04 Laura Rivera**, including commissions, responsibilities, confidentiality, and legal obligations.

## Signatures

Client Signature: ____________________  
Horizon Haven Agent Signature: ____________________  
Date: 2023-03-10