# Listing Agreement - John Martinez

- **Contract Type:** Listing Agreement  
- **Client Name:** John Martinez  
- **Effective Date:** 2023-12-26  
- **Expiration Date:** 2026-10-31  
- **Agent:** 04 Laura Rivera  
- **Property Address:** 6660 Main St, Seattle, USA  

## Terms and Conditions

This listing agreement is entered into by and between **John Martinez** and Horizon Haven Realty. It outlines the terms of engagement for real estate services rendered by **04 Laura Rivera**, including commissions, responsibilities, confidentiality, and legal obligations.

## Signatures

Client Signature: ____________________  
Horizon Haven Agent Signature: ____________________  
Date: 2023-12-26