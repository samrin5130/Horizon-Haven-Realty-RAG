# Purchase Agreement - Daniel Brown

- **Contract Type:** Purchase Agreement  
- **Client Name:** Daniel Brown  
- **Effective Date:** 2023-07-15  
- **Expiration Date:** 2025-10-27  
- **Agent:** 01 Bradley Kim  
- **Property Address:** 8880 Maple Drive, Chicago, USA  

## Terms and Conditions

This purchase agreement is entered into by and between **Daniel Brown** and Horizon Haven Realty. It outlines the terms of engagement for real estate services rendered by **01 Bradley Kim**, including commissions, responsibilities, confidentiality, and legal obligations.

## Signatures

Client Signature: ____________________  
Horizon Haven Agent Signature: ____________________  
Date: 2023-07-15