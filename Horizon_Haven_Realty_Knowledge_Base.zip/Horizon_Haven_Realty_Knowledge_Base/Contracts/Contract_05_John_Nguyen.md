# Buyer Agreement - John Nguyen

- **Contract Type:** Buyer Agreement  
- **Client Name:** John Nguyen  
- **Effective Date:** 2024-03-04  
- **Expiration Date:** 2026-04-04  
- **Agent:** 12 Sophie Smith  
- **Property Address:** 2091 Elm Rd, Chicago, USA  

## Terms and Conditions

This buyer agreement is entered into by and between **John Nguyen** and Horizon Haven Realty. It outlines the terms of engagement for real estate services rendered by **12 Sophie Smith**, including commissions, responsibilities, confidentiality, and legal obligations.

## Signatures

Client Signature: ____________________  
Horizon Haven Agent Signature: ____________________  
Date: 2024-03-04