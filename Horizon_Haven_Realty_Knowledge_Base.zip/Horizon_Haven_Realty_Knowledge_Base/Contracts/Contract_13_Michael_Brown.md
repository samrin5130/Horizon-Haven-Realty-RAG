# Listing Agreement - Michael Brown

- **Contract Type:** Listing Agreement  
- **Client Name:** Michael Brown  
- **Effective Date:** 2024-03-28  
- **Expiration Date:** 2025-10-01  
- **Agent:** 14 Mark Tran  
- **Property Address:** 6605 Main St, Miami, USA  

## Terms and Conditions

This listing agreement is entered into by and between **Michael Brown** and Horizon Haven Realty. It outlines the terms of engagement for real estate services rendered by **14 Mark Tran**, including commissions, responsibilities, confidentiality, and legal obligations.

## Signatures

Client Signature: ____________________  
Horizon Haven Agent Signature: ____________________  
Date: 2024-03-28