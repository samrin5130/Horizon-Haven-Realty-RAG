# Property Listings

## Residential Properties
- 241 Maple Grove Lane, San Jose, CA – 4BR/3BA – $1.2M  
- 19 Sunset Blvd, Austin, TX – 3BR/2BA – $875K
- 1234 Maple Street, San Francisco, CA 94105 – $3.2M
- 5678 Pine Road, Palo Alto, CA 94306 – $2.8M
- 9012 Oak Avenue, San Jose, CA 95124 – $2.5M

## Commercial Properties
- 500 Business Park Drive, Dallas, TX – Office Space – $3.4M  
- 1400 Market Street, San Francisco, CA – Retail Space – $7.2M

## Rental Listings
- 332 Riverwalk Apt 201, Chicago, IL – 2BR – $2,400/mo  
- 715 Pinecrest Drive, Seattle, WA – 3BR Home – $3,100/mo