# Frequently Asked Questions

**Q1:** Do I need to be pre-approved for a mortgage before house hunting?  
**A1:** It's highly recommended to speed up the offer process and show sellers you're serious.

**Q2:** What is the agent commission rate?  
**A2:** Typically 5-6%, split between buyer and seller agents.

**Q3:** How long does it take to close a property deal?  
**A3:** On average, 30-45 days, depending on financing and contingencies.

**Q4:** Can Horizon Haven Realty help with property management?  
**A4:** Yes, we offer full-service property management for both residential and commercial properties.